# Guia Prático de Publicação na Hostinger
**Sistema: RIOS – Gestão de Escalas**

O sistema foi preparado e empacotado para ser publicado na **Hostinger** de maneira imediata, sem necessidade de instalar Node.js ou compilar nada no seu computador pessoal se não desejar.

---

## Método 1: Download Direto no Sistema (Mais Rápido e Recomendado)

O sistema agora possui um gerador e empacotador nativo. Você pode baixar o pacote `.zip` pronto para a pasta `public_html` diretamente da tela da aplicação:

1. **Clique no botão de nuvem no topo da tela ou no rodapé da barra lateral**:
   - No cabeçalho superior (ou na barra lateral), clique no ícone **"Publicar na Hostinger"** (ícone de nuvem com seta).
   - Um modal será aberto com o botão **"Baixar Pacote Hostinger (.zip)"**.
   - Ao clicar, o arquivo `rios_hostinger_public_html.zip` (~428 KB) será baixado para o seu computador.

2. **Acesse a Hostinger**:
   - Acesse o painel da Hostinger (**hPanel**): [https://hpanel.hostinger.com](https://hpanel.hostinger.com).
   - Vá em **Sites** > Selecione seu domínio > **Gerenciador de Arquivos** (*File Manager*).
   - Abra a pasta **`public_html`**.

3. **Enviar e Extrair**:
   - Faça o upload do arquivo `rios_hostinger_public_html.zip` para dentro de `public_html`.
   - Clique com o botão direito sobre o arquivo enviado e escolha **Extrair** (*Extract*).
   - Confirme a extração na pasta atual (`public_html`).
   - Os seguintes arquivos/pastas serão descompactados:
     - `index.html` (página principal da aplicação)
     - `assets/` (estilos CSS, scripts e fontes otimizadas)
     - `.htaccess` (regras Apache/LiteSpeed com suporte a SPA, compressão Gzip e cache)

4. **Ativar o Certificado SSL (HTTPS Gratuito)**:
   - No hPanel da Hostinger, vá em **Segurança** > **SSL**.
   - Instale o certificado gratuito Let's Encrypt para o seu domínio e marque a opção **Forçar HTTPS**.

Pronto! Seu sistema estará funcionando com rota direta, persistência em nuvem (Firebase Firestore) e contingência local.

---

## Método 2: Compilação Manual via Terminal (Para Desenvolvedores)

Se você exportou o código-fonte via "Export to ZIP" no AI Studio e quer compilar você mesmo:

1. Extraia o código-fonte em seu computador.
2. Abra o terminal na pasta e execute:
   ```bash
   npm install
   npm run build
   ```
3. O comando acima irá:
   - Compilar a aplicação React com Vite.
   - Gerar a pasta `dist/`.
   - Copiar o `.htaccess` configurado.
   - Gerar automaticamente o arquivo `hostinger_public_html.zip`.
4. Envie o conteúdo de `dist/` para a pasta `public_html` da Hostinger.

---

## Método 3: Hospedagem VPS ou Node.js na Hostinger

Caso deseje rodar o servidor Express com o endpoint `/api/ai/ask` via backend:

1. No painel VPS/Node.js da Hostinger:
   - Versão do Node.js: **18+** ou **20+**.
   - Arquivo de inicialização: `dist/server.cjs` ou `server.ts`.
   - A porta é lida automaticamente de `process.env.PORT`.
2. Variáveis de ambiente:
   - `GEMINI_API_KEY`: sua chave de API do Google AI Studio.
   - `NODE_ENV`: `production`.
