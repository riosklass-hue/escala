import React, { useState } from 'react';
import {
  X,
  CloudUpload,
  Download,
  CheckCircle2,
  ExternalLink,
  ShieldCheck,
  FileCode,
  FolderArchive,
  AlertTriangle,
  Copy,
  Check,
  Layers,
  Sparkles,
  Info,
} from 'lucide-react';

interface ModalHostingerDeployProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ModalHostingerDeploy: React.FC<ModalHostingerDeployProps> = ({
  isOpen,
  onClose,
}) => {
  const [downloadingHostinger, setDownloadingHostinger] = useState(false);
  const [downloadingSource, setDownloadingSource] = useState(false);
  const [copiedLink, setCopiedLink] = useState<string | null>(null);

  if (!isOpen) return null;

  const isInsideIframe = typeof window !== 'undefined' && window.self !== window.top;

  const handleDownloadHostinger = () => {
    setDownloadingHostinger(true);
    // Abrir endpoint direto em nova janela para contornar restrição de sandbox do iframe
    const downloadUrl = '/api/download/hostinger-zip';
    window.open(downloadUrl, '_blank');
    setTimeout(() => setDownloadingHostinger(false), 2000);
  };

  const handleDownloadSource = () => {
    setDownloadingSource(true);
    const downloadUrl = '/api/download/codigo-fonte-zip';
    window.open(downloadUrl, '_blank');
    setTimeout(() => setDownloadingSource(false), 2000);
  };

  const handleOpenInNewTab = () => {
    window.open(window.location.href, '_blank');
  };

  const handleCopyLink = (path: string) => {
    const fullUrl = `${window.location.origin}${path}`;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(fullUrl);
      setCopiedLink(path);
      setTimeout(() => setCopiedLink(null), 2500);
    } else {
      prompt('Copie o link direto de download:', fullUrl);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/80 backdrop-blur-xs animate-fadeIn"
      id="modal-hostinger-deploy"
    >
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[94vh]">
        {/* Top Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 px-6 py-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-indigo-300">
              <CloudUpload className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold">Download dos Arquivos do Sistema</h3>
                <span className="px-2 py-0.5 text-xs font-semibold bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 rounded-full">
                  Pronto para Envio
                </span>
              </div>
              <p className="text-xs text-slate-300">
                Pacotes compilados para Hostinger (<code className="text-amber-300 bg-slate-800 px-1 rounded">public_html</code>) ou código-fonte
              </p>
            </div>
          </div>
          <button
            type="button"
            id="btn-fechar-modal-hostinger"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-sm text-slate-700">
          {/* Alerta de Contorno de Bloqueio do Iframe */}
          <div className="bg-amber-50/90 border border-amber-200/90 rounded-xl p-3.5 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="space-y-1 text-xs">
              <p className="font-bold text-amber-900">
                Atenção: Por que o arquivo não estava baixando?
              </p>
              <p className="text-amber-800 leading-relaxed">
                Por segurança, os navegadores modernos (Google Chrome, Edge) bloqueiam downloads iniciados dentro da moldura de visualização (iframe) do AI Studio. 
                Os botões abaixo agora abrem o download <strong>direto em nova aba</strong> para que o navegador baixe o arquivo no seu computador sem nenhum bloqueio.
              </p>
              <div className="pt-1">
                <button
                  type="button"
                  onClick={handleOpenInNewTab}
                  className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-200/80 hover:bg-amber-300 text-amber-950 font-bold rounded-lg transition-colors cursor-pointer text-xs"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Ou abra o Sistema em Nova Aba Completa</span>
                </button>
              </div>
            </div>
          </div>

          {/* PACOTE 1: HOSTINGER (PUBLIC_HTML) */}
          <div className="bg-gradient-to-br from-indigo-50/90 to-blue-50/60 border-2 border-indigo-200 rounded-2xl p-5 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-start gap-3.5">
                <div className="w-12 h-12 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-indigo-600/20">
                  <FolderArchive className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-slate-900 text-base">
                      1. Pacote Pronto para a Hostinger (.ZIP)
                    </h4>
                    <span className="px-2 py-0.5 text-[10px] font-black uppercase tracking-wider bg-indigo-600 text-white rounded-full">
                      Recomendado
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">
                    Arquivo: <strong className="text-indigo-900 font-mono">rios_hostinger_public_html.zip</strong> (~535 KB)
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    Contém exatamente: <code className="font-mono bg-white px-1 py-0.5 rounded border border-slate-200 text-slate-800">index.html</code>, pasta <code className="font-mono bg-white px-1 py-0.5 rounded border border-slate-200 text-slate-800">assets/</code> e <code className="font-mono bg-white px-1 py-0.5 rounded border border-slate-200 text-slate-800">.htaccess</code>.
                  </p>
                </div>
              </div>

              <div className="flex flex-col sm:items-end gap-2 shrink-0">
                <a
                  href="/api/download/hostinger-zip"
                  target="_blank"
                  rel="noopener noreferrer"
                  download="rios_hostinger_public_html.zip"
                  onClick={handleDownloadHostinger}
                  id="btn-download-hostinger-zip"
                  className="inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md shadow-indigo-600/30 transition-all active:scale-98 cursor-pointer"
                >
                  {downloadingHostinger ? (
                    <>
                      <Download className="w-4 h-4 animate-bounce" />
                      Iniciando Download...
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4" />
                      Baixar Pacote Hostinger (.ZIP)
                    </>
                  )}
                </a>

                <button
                  type="button"
                  onClick={() => handleCopyLink('/api/download/hostinger-zip')}
                  className="inline-flex items-center justify-center gap-1.5 text-[11px] text-slate-500 hover:text-indigo-600 cursor-pointer transition-colors"
                >
                  {copiedLink === '/api/download/hostinger-zip' ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-600" />
                      <span className="text-emerald-700 font-medium">Link copiado para a área de transferência!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      <span>Copiar link direto de download</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* O que aparece ao abrir no 7-Zip */}
            <div className="mt-3.5 pt-3.5 border-t border-indigo-100 bg-white/70 rounded-xl p-3 text-xs">
              <span className="font-semibold text-slate-800 block mb-1">
                Ao abrir o ZIP no 7-Zip ou WinRAR, você verá exatamente:
              </span>
              <div className="font-mono text-[11px] text-slate-700 bg-slate-900 text-slate-100 p-2.5 rounded-lg space-y-0.5">
                <div>📁 public_html/ (ou raiz do arquivo)</div>
                <div className="pl-4">📄 index.html</div>
                <div className="pl-4">📁 assets/</div>
                <div className="pl-8 text-slate-400">📄 index-IL7z0PW2.js</div>
                <div className="pl-8 text-slate-400">📄 index-DGrcJZGk.css</div>
                <div className="pl-4">⚙️ .htaccess (configuração de rotas SPA e SSL)</div>
              </div>
            </div>
          </div>

          {/* PACOTE 2: CÓDIGO-FONTE COMPLETO */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-slate-800 text-white flex items-center justify-center shrink-0">
                  <FileCode className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">
                    2. Código-Fonte Completo do Projeto (.ZIP)
                  </h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Arquivo: <strong className="text-slate-800 font-mono">rios_codigo_fonte.zip</strong> (~200 KB)
                  </p>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Contém: <code className="font-mono">src/</code>, <code className="font-mono">package.json</code>, <code className="font-mono">vite.config.ts</code>, <code className="font-mono">server.ts</code>. Para desenvolvedores e backup.
                  </p>
                </div>
              </div>

              <div className="flex flex-col sm:items-end gap-1.5 shrink-0">
                <a
                  href="/api/download/codigo-fonte-zip"
                  target="_blank"
                  rel="noopener noreferrer"
                  download="rios_codigo_fonte.zip"
                  onClick={handleDownloadSource}
                  className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs rounded-xl transition-all cursor-pointer"
                >
                  {downloadingSource ? (
                    <>
                      <Download className="w-3.5 h-3.5 animate-bounce" />
                      Baixando...
                    </>
                  ) : (
                    <>
                      <Download className="w-3.5 h-3.5" />
                      Baixar Código-Fonte (.ZIP)
                    </>
                  )}
                </a>

                <button
                  type="button"
                  onClick={() => handleCopyLink('/api/download/codigo-fonte-zip')}
                  className="inline-flex items-center justify-center gap-1.5 text-[11px] text-slate-500 hover:text-slate-800 cursor-pointer transition-colors"
                >
                  {copiedLink === '/api/download/codigo-fonte-zip' ? (
                    <span className="text-emerald-700 font-medium">Link copiado!</span>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      <span>Copiar link do código</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Passo a Passo Ilustrado para a Hostinger */}
          <div>
            <h4 className="font-bold text-slate-900 mb-2.5 flex items-center gap-2 text-sm">
              <span>Instruções para publicar na Hostinger em 3 passos:</span>
            </h4>
            <div className="space-y-2.5 text-xs">
              {/* Passo 1 */}
              <div className="flex items-start gap-3 p-3 rounded-xl border border-slate-200 bg-white">
                <div className="w-6 h-6 rounded-full bg-slate-900 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                  1
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-slate-900">
                    Baixe o pacote <span className="text-indigo-600 font-mono">rios_hostinger_public_html.zip</span>
                  </p>
                  <p className="text-slate-500 mt-0.5">
                    Utilize o botão roxo acima. O arquivo será salvo na pasta Downloads do seu computador.
                  </p>
                </div>
              </div>

              {/* Passo 2 */}
              <div className="flex items-start gap-3 p-3 rounded-xl border border-slate-200 bg-white">
                <div className="w-6 h-6 rounded-full bg-slate-900 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                  2
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-slate-900">
                    Acesse o Gerenciador de Arquivos na Hostinger
                  </p>
                  <p className="text-slate-500 mt-0.5">
                    No <strong>hPanel</strong>, abra <strong>Sites</strong> &gt; seu domínio &gt; <strong>Gerenciador de Arquivos</strong> (File Manager) e entre na pasta <code className="bg-slate-100 px-1 py-0.5 rounded font-mono font-bold text-slate-800">public_html</code>.
                  </p>
                </div>
              </div>

              {/* Passo 3 */}
              <div className="flex items-start gap-3 p-3 rounded-xl border border-slate-200 bg-white">
                <div className="w-6 h-6 rounded-full bg-slate-900 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                  3
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-slate-900">
                    Envie o ZIP e clique em Extrair (Extract)
                  </p>
                  <p className="text-slate-500 mt-0.5">
                    Faça o upload do <code className="font-mono text-slate-800">rios_hostinger_public_html.zip</code> para dentro da pasta <code className="font-mono text-slate-800">public_html</code>. Clique com o botão direito no arquivo e escolha <strong>Extrair</strong> (*Extract*). O sistema ficará no ar na mesma hora no seu domínio!
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Destaques Técnicos Já Inclusos */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
              <div className="flex items-center gap-2 font-semibold text-xs text-slate-900">
                <FileCode className="w-4 h-4 text-indigo-600" />
                <span>Arquivo .htaccess Integrado</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                Previne erro 404 ao recarregar rotas da aplicação, habilita compressão gzip/deflate e cabeçalhos de segurança no Apache da Hostinger.
              </p>
            </div>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
              <div className="flex items-center gap-2 font-semibold text-xs text-slate-900">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Ativação de SSL Gratuito</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                No hPanel, vá em Segurança &gt; SSL, instale o Let&apos;s Encrypt e marque &quot;Forçar HTTPS&quot; para conexão segura com cadeado verde.
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 border-t border-slate-200 px-6 py-3.5 flex items-center justify-between shrink-0">
          <a
            href="https://hpanel.hostinger.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-indigo-600 transition-colors"
          >
            <span>Abrir Painel da Hostinger (hPanel)</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>

          <button
            type="button"
            id="btn-concluir-hostinger-modal"
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-xl transition-colors cursor-pointer"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};

