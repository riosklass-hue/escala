import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: "5mb" }));

// Lazy init Gemini client
let geminiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!geminiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is required");
    }
    geminiClient = new GoogleGenAI({ apiKey });
  }
  return geminiClient;
}

// Health check
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    hasApiKey: !!process.env.GEMINI_API_KEY,
    system: "RIOS – Gestão de Escalas",
  });
});

// Download ready-to-use Hostinger public_html.zip
app.get("/api/download/hostinger-zip", (_req, res) => {
  const possiblePaths = [
    path.join(process.cwd(), "public", "hostinger_public_html.zip"),
    path.join(process.cwd(), "hostinger_public_html.zip"),
    path.join(process.cwd(), "dist", "hostinger_public_html.zip"),
  ];
  const zipPath = possiblePaths.find((p) => fs.existsSync(p));
  if (zipPath) {
    res.setHeader("Content-Disposition", 'attachment; filename="rios_hostinger_public_html.zip"');
    res.setHeader("Content-Type", "application/zip");
    return res.download(zipPath, "rios_hostinger_public_html.zip");
  }
  return res.status(404).json({ error: "Pacote Hostinger não encontrado. Execute o build primeiro." });
});

// Download full project source code (.zip)
app.get("/api/download/codigo-fonte-zip", (_req, res) => {
  const possiblePaths = [
    path.join(process.cwd(), "public", "rios_codigo_fonte.zip"),
    path.join(process.cwd(), "rios_codigo_fonte.zip"),
  ];
  const zipPath = possiblePaths.find((p) => fs.existsSync(p));
  if (zipPath) {
    res.setHeader("Content-Disposition", 'attachment; filename="rios_codigo_fonte.zip"');
    res.setHeader("Content-Type", "application/zip");
    return res.download(zipPath, "rios_codigo_fonte.zip");
  }
  return res.status(404).json({ error: "Pacote de código-fonte não encontrado." });
});

// API Route for AI Assistant (Grounded in RIOS Golden Rule)
app.post("/api/ai/ask", async (req, res) => {
  try {
    const { prompt, riosSummary } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: "Prompt é obrigatório." });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.json({
        fallback: true,
        answer: null,
        message: "Chave GEMINI_API_KEY não configurada. Ativando motor de regras nativo.",
      });
    }

    const ai = getGeminiClient();

    const systemPrompt = `Você é a IA assistente oficial do sistema "RIOS – GESTÃO DE ESCALAS".
Seu papel exclusivo é ser o ASSISTENTE DE ALOCAÇÃO E SUBSTITUIÇÃO DE PROFESSORES.

===========================================================
REGRA DE OURO DO SISTEMA (ABSOLUTA E INVIOLÁVEL):
===========================================================
A TURMA É FIXA.
A ESCOLA É FIXA.
A SALA É FIXA.
O HORÁRIO É FIXO.
O COMPONENTE CURRICULAR É FIXO.
O CURSO É FIXO.
O PROFESSOR É O ELEMENTO QUE PODE SER MOVIMENTADO.

Você NUNCA deve reorganizar automaticamente as turmas.
Você NUNCA deve mudar ou sugerir mudar escolas, salas, horários, dias, turmas, cursos ou componentes.
Você deve recomendar e analisar SOMENTE alterações e alocações relativas ao PROFESSOR.

Responda sempre em português brasileiro de forma direta, clara, profissional e objetiva para o gestor escolar.

===========================================================
DADOS ATUAIS DO SISTEMA RIOS:
===========================================================
${riosSummary || "Dados padrões do sistema RIOS carregados."}
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: [
        {
          role: "user",
          parts: [{ text: `${systemPrompt}\n\nPergunta do Gestor: "${prompt}"` }],
        },
      ],
    });

    const answer = response.text || "Sem resposta gerada.";
    return res.json({ answer, fallback: false });
  } catch (error: any) {
    console.error("Gemini server error:", error);
    return res.json({
      fallback: true,
      error: error?.message || "Erro de conexão com a IA.",
      answer: null,
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[RIOS] Servidor operacional executando na porta ${PORT}`);
  });
}

startServer();
